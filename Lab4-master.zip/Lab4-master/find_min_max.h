#ifndef FIND_MIN_MAX_H
#define FIND_MIN_MAX_H

#include "utils.h"

struct MinMax GetMinMax(int *array, unsigned int begin, unsigned int end);

#endif
